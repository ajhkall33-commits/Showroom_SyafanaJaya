<link rel="stylesheet" href="https://cdn.datatables.net/1.11.0/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">
<style>
    .pointer {
        cursor: pointer;
    }
    .hiddenRow {
    padding: 0 !important;
   }
   .form-group {
      margin-bottom: 0.50em;
   }
   .mb-10 {
    margin-bottom: 10px;
   }
   .lg-stat{
      width: 15px;
      height: 15px;
      border-radius: 50%;
   }
   .align-middle {
      padding-top: 2px;
    
      padding-left: 10px;
   }
   .modal-black{
      background-color: #131a22;
   }
   .modal-wt {
      color: #fff;
   }
   .pd-2{
      padding-left: 5px;
      padding-right: 5px;
   }
   .label-primary {
    background: #4e79a7;
   }
   .label-success {
    background: #59a14f;
   }
   .label-danger {
    background: #e15759;
   }
   td, th {
    white-space: normal;
   }
   .btn.btn-icon2 {
      width: 35px;
      line-height: 20px;
      height: 35px;
      padding: 8px;
      text-align: center;
   }
   .table-bordered {
    border: 1px solid #EBEBEB;
   }
   table {
   
    border-spacing: 2px;
   }
   .table-bordered td, .table-bordered th {
      padding: 10px;
   }
   .table .thead-dark th {
      color: #fff;
      background-color: #878888b8;
      border-color: #878d93f5;
   }
   .putih{
      color: #fff;
   }

   .center{
   vertical-align: middle;
   text-align: center;
}

</style>
<div id="spinner" class="">
   <div class="loader is-loading">
      <div class="lds-dual-ring"></div>
   </div>
</div>
<div class="page-header card">
   <div class="row align-items-end">
      <div class="col-lg-8">
         <div class="page-header-title">
            <i class="feather icon-home bg-c-blue"></i>
            <div class="d-inline">
               <h5><?=$title?></h5>
               <span><?=$title_des?></span>
            </div>
         </div>
      </div>
      <div class="col-lg-4">
         <div class="page-header-breadcrumb">
         </div>
      </div>
   </div>
</div>
<div class="pcoded-inner-content">
   <div class="main-body">
      <div class="page-wrapper">
         <div class="page-body">
            <!-- [ page content ] start -->
               <div class="row">
                  <div class="col-md-12">
                     <div class="card ">
                        <div class="card-block">
                            <div class="row" id="export">
                               <?php if (is_sk_manager()): ?>
                               <div class="col-md-4 mb-2">
                                  <div class="form-group">
                                     <label>Unit</label>
                                     <?= render_unit_filter_select('filter_unit', 'FilterData()', 'form-control') ?>
                                  </div>
                               </div>
                               <?php endif; ?>
                               <div class="<?= is_sk_manager() ? 'col-md-8' : 'col-md-12' ?>">
                                  <div class="pull-right putih mb-10">
                                     <a class="btn btn-primary" onclick="AddData()"><i class="fa fa-file-excel-o "></i> Tambah</a>
                                  </div>
                               </div>
                            </div>
                       
                              <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
                                   <div class="rv-view-switcher">
                                      <button type="button" class="btn btn-sm btn-outline-primary active" id="btn-view-table" onclick="setViewMode('table')"><i class="feather icon-list"></i> Table</button>
                                      <button type="button" class="btn btn-sm btn-outline-primary" id="btn-view-card" onclick="setViewMode('card')"><i class="feather icon-grid"></i> Card</button>
                                   </div>
                                </div>
                                <div class="rv-table-view-container">
                                   <div class="table-responsive rv-table-wrapper">
                                      <table class="table table-condensed table-striped table-bordered" id="tabel-data">
                                 <thead class="thead-blue">
                                    <tr>
                                    
                                       <th class="cemter-t">Kategori Perangkat</th>
                                       <th class="cemter-t">Status</th>
                                       <th class="cemter-t">Aksi</th>
                                    </tr>
                                 </thead>
                                 <tbody id="Data-AP">
                                 </tbody>
                              </table>
                                   </div>
                                </div>
                                <div class="rv-card-view-container" style="display:none;">
                                   <div class="rv-cards-grid" id="card-data"></div>
                                </div>
                        
                        </div>
                     </div>
                  </div>
               </div>
            <!-- [ page content ] end -->
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="m-menu" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
       <div class="modal-content">
          <div class="modal-header">
             <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
             <span aria-hidden="true">&times;</span>
             </button>
          </div>
          <form onsubmit="return SaveGroup(this)">
             <div class="modal-body">
                <div class="form-group row">
                   <label class="col-sm-2 col-form-label">Jenis Alat</label>
                   <div class="col-sm-6">
                      <input type="text" class="form-control" name="nama" id="nama" required>
                   </div>
                </div>
              
                <div class="form-group row">
                   <label class="col-sm-2 col-form-label">Status</label>
                   <div class="col-sm-10">
                      <select class="form-control" name="status"  id="status" required>
                         <option value="1">Active</option>
                         <option value="0">Inactive</option>
                      </select>
                   </div>
                </div>
             </div>
             <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                <button class="btn btn-primary" >YA</button>
             </div>
          </form>
       </div>
    </div>
 </div>

 <!-- Modal Konfirmasi Delete -->
<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="confirmModalLabel">Notifikasi</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
               <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            Apakah Anda yakin ingin menghapus <span id="deleteItemNama"></span>?
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
            <button type="button" class="btn btn-primary" id="btnConfirmDelete">Ya</button>
         </div>
      </div>
   </div>
</div>

<!-- Modal Notifikasi Item Dihapus -->
<div class="modal fade" id="NotifModal" tabindex="-1" role="dialog" aria-labelledby="deletedModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deletedModalLabel">Notifikasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>



<!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script> -->
<script src="https://cdn.datatables.net/1.11.0/js/jquery.dataTables.min.js"></script>
<!-- <script src="<?= base_url("assets") ?>/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js"></script> -->

<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.0.1/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<script>
   var start = "";
   var end = "";
   
      function show () {
         $("#spinner").addClass("show");
      
      }
      function hide () {
         $("#spinner").removeClass("show");
      }
      FilterData();
    
      function FilterData(){
         show();
         var formData = new FormData();
         formData.append('filter_unit', $('#filter_unit').val() || '');
         
         $.ajax({
               url: "<?=base_url()?>jenis_perangkat/LoadData",
               type: 'post',
               data: formData,
               contentType: false,
               processData: false,

               success: function(r){
                  var json = JSON.parse(r);
                  var header_table = "";
                  var cards_html = "";
                  var pag = "";
                  jQuery.each(json, function( i, val ) {
                     var row = "";
                     var btn = "";
                     if (val['id_unit'] == 0) {
                        btn = "";
                     } else {
                        btn = `<button class="btn waves-effect waves-light btn-danger btn-icon" onclick="confirmDelete(${val['id_jenisperangkat']}, '${(val['nama'] || '').replace(/"/g, '&quot;')}')" title="Hapus"><i class="fa fa-trash"></i></button>`;   
                     }
                     var editBtn = `<button class="btn waves-effect waves-light btn-primary btn-icon" onclick="EditData(${val['id_jenisperangkat']})" title="Edit"><i class="feather icon-edit"></i></button>`;

                     header_table +=`<tr>
                                        <td class="center font-weight-bold text-primary">${val['nama'] || '-'}</td>
                                        <td class="center">${val['label_status'] || ''}</td>
                                        <td class="center">
                                           ${editBtn}
                                           ${btn}
                                        </td>
                                     </tr>`;

                     cards_html += `
                     <div class="rv-card-item">
                        <div class="rv-card-header">
                           <div>
                              <span class="rv-card-title text-primary"><i class="feather icon-layers mr-1"></i> ${val['nama'] || '-'}</span>
                           </div>
                           <div>${val['label_status'] || ''}</div>
                        </div>
                        <div class="rv-card-footer d-flex justify-content-end" style="gap:5px;">
                           ${editBtn}
                           ${btn}
                        </div>
                     </div>`;
                  });
                
                  $('#tabel-data > tbody:last-child').html(header_table);
                  if (cards_html === "") {
                     $('#card-data').html(renderEmptyCard("Belum ada kategori perangkat"));
                  } else {
                     $('#card-data').html(cards_html);
                  }
                  if (typeof setViewMode === "function") {
                     if (typeof setViewMode === 'function') { setViewMode(typeof MPS_VIEW_MODE !== 'undefined' ? MPS_VIEW_MODE : 'table', false); }
                  }
                  hide ();
               }, error: function(){
                  hide ();
               }
         });   
         return false;
      }
    
     
    
    function AddData(){
      // show();
      $('#m-menu').modal('show');
      $('#m-menu').find('.modal-title').html('Tambah Menu Baru');   
      $('#m-menu').find('form').attr('onsubmit','return SaveData(this)');
    

    }

    function EditData(id){
      // show();
      $('#m-menu').modal('show');
      $('#m-menu').find('.modal-title').html('Edit Menu');   
      $('#m-menu').find('form').attr('onsubmit','return UpdateData(this,\''+id+'\')');
      $.ajax({
               url: "<?=base_url()?>jenis_perangkat/EditData/"+id,
               type: 'post',
               // data: formData,
               contentType: false,
               processData: false,

               success: function(r){
                 
                  var json = JSON.parse(r);
                  $('#nama').val(json['nama']);  
                  $('#parent_id').val(json['parent_id']);  
                  console.log(json);  
               
               }, error: function(){
                  hide ();
               }
         }); 
         return false;
    }

    function Delete(id){
      // show();
      // $('#m-menu').modal('show');
      // $('#m-menu').find('.modal-title').html('Infomation Realisasi Kinerja');   
      // $('#Mm-menu').find('form').attr('onsubmit','return SaveData(this)');
     
      $.ajax({
         url:  '<?=base_url('jenis_perangkat/')?>Delete/'+id,
       
         type: 'post',
         //data: formData,
         contentType: false,
         processData: false,
         success: function(r){
            // $(f)[0].reset(); 
            // $('#MasterIndikator').modal('hide');
            
            FilterData();
            // ViewDetail(id,date);
            hide(); 
         }, error: function(){
            hide(); 
         }
      });
      return false;
    }


    function UpdateData(f,id){
      show();
      var formData = new FormData($(f)[0]);
      // formData.append('id', id);
      $.ajax({
         url:  '<?=base_url('jenis_perangkat/')?>Update/'+id,
       
         type: 'post',
         data: formData,
         contentType: false,
         processData: false,
         success: function(r){
            var json = JSON.parse(r);
             $(f)[0].reset(); 
             $('#m-menu').modal('hide');
            NF(json);

           FilterData();;
            // ViewDetail(id,date);
          hide(); 
         }, error: function(){
            hide(); 
         }
      });

      return false;
   }

   function SaveData(f){
      show();
      var formData = new FormData($(f)[0]);
      // formData.append('id', id);
      $.ajax({
         url:  '<?=base_url('jenis_perangkat/')?>SaveData/',
       
         type: 'post',
         data: formData,
         contentType: false,
         processData: false,
         success: function(r){
            // $(f)[0].reset(); 
            $('#m-menu').modal('hide');
            $('#NotifModal').modal('show');
            $('#NotifModal').find('.modal-body').html('Data berhasil ditambahkan');
           FilterData();
        
            // ViewDetail(id,date);
          hide(); 
         }, error: function(){
            hide(); 
         }
      });

      return false;
   }


   function confirmDelete(id, nama_masalah) {
      $('#confirmModal').modal('show');
      $('#deleteItemNama').text(nama_masalah);

      // Fungsi untuk mengeksekusi delete jika tombol "Ya" ditekan
      $('#btnConfirmDelete').click(function() {
         $('#confirmModal').modal('hide');
         Delete(id);
         $('#NotifModal').modal('show');
         $('#NotifModal').find('.modal-body').html('Data berhasil dihapus');
      });
   }


</script>